load('CareerMP')
setExtensionUnloadMode('CareerMP', 'manual')

load('/career/mpCareer')
setExtensionUnloadMode('/career/mpCareer', 'manual')

load('/freeroam/mpBigMapMode')
setExtensionUnloadMode('/freeroam/mpBigMapMode', 'manual')
